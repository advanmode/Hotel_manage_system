Apache Commons DBCP
===========================

Welcome to the DBCP component of the Apache Commons
project (http://commons.apache.org).

DBCP version 2 requires JDK 1.7.

DBCP can be built using either Maven or Ant. When building using Ant,
Locations of dependent jars for the Ant build need to be specified in 
build.properties. There is a build.properties.sample file included in the
source distribution.

See http://commons.apache.org/dbcp/ for additional and 
up-to-date information on Commons DBCP.

